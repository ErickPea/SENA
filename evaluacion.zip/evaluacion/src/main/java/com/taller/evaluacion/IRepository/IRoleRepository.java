package com.taller.evaluacion.IRepository;

import com.taller.evaluacion.Entity.Role;

public interface IRoleRepository extends IBaseRepository<Role, Long> {

}
