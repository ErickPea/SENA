package com.taller.evaluacion.DTO;

public interface UserDTO extends IGenericDto {

}
