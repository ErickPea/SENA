package com.taller.evaluacion.DTO;

public interface IGenericDto {

	Long getId();

	Boolean getState();

}
