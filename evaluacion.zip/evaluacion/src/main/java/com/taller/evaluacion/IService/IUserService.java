package com.taller.evaluacion.IService;

import com.taller.evaluacion.Entity.User;

public interface IUserService extends IBaseService<User> {

}
