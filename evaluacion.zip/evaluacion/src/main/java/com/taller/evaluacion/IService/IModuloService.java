package com.taller.evaluacion.IService;

import com.taller.evaluacion.Entity.ModuloEntity;

public interface IModuloService extends IBaseService<ModuloEntity> {

}
