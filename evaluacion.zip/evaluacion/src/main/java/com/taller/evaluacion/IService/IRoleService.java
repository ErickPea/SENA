package com.taller.evaluacion.IService;

import com.taller.evaluacion.Entity.Role;

public interface IRoleService extends IBaseService<Role> {

}
