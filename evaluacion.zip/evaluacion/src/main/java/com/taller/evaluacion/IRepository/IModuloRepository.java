package com.taller.evaluacion.IRepository;

import com.taller.evaluacion.Entity.ModuloEntity;

public interface IModuloRepository extends IBaseRepository<ModuloEntity, Long> {

}
