package com.taller.evaluacion.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.taller.evaluacion.Entity.ABaseEntity;
import com.taller.evaluacion.Entity.ModuloEntity;
import com.taller.evaluacion.Entity.Role;
import com.taller.evaluacion.IRepository.IBaseRepository;
import com.taller.evaluacion.IRepository.IModuloRepository;
import com.taller.evaluacion.IRepository.IRoleRepository;
import com.taller.evaluacion.IService.IModuloService;

@Service
public class ModuloService extends ABaseService<ModuloEntity> implements IModuloService {

	@Autowired
	private IModuloRepository repository;

	@Override
	protected IBaseRepository<ModuloEntity, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}

}
