package com.taller.evaluacion.IRepository;

import com.taller.evaluacion.Entity.User;

public interface IUserRepository extends IBaseRepository<User, Long> {

}
