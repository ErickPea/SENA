package com.taller.evaluacion.Controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.taller.evaluacion.Entity.ModuloEntity;

import com.taller.evaluacion.IService.IModuloService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/v1/api/modulo")
public class ModuloController extends ABaseController<ModuloEntity, IModuloService> {

	protected ModuloController(IModuloService service) {
		super(service, "ModuloEntity");

	}

}
