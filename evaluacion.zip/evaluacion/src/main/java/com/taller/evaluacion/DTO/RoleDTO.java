package com.taller.evaluacion.DTO;

public interface RoleDTO extends IGenericDto {

}
