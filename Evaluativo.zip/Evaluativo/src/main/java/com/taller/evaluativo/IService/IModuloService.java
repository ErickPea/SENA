package com.taller.evaluativo.IService;

import com.taller.evaluativo.Entity.ModuloEntity;

public interface IModuloService  extends IBaseService<ModuloEntity>{

}
