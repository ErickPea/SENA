package com.taller.evaluativo.Entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table (name = "modulo")
public class ModuloEntity extends ABaseEntity {
	
	@Column(name = "nombre " , length = 100, nullable =false)
	private String nombre
	;
	
	@Column(name = "role " , length = 100, nullable =false)
	private String role
	;
	
	@ManyToMany (fetch = FetchType.EAGER )
	@JoinTable(name= "modulo_role", joinColumns = @JoinColumn(name = "modulo_id"), inverseJoinColumns = @JoinColumn(name = "role_id") )
	private List<Role> roles;

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}
	

}
