package com.taller.evaluativo.IService;

import com.taller.evaluativo.Entity.User;

public interface IUserService extends IBaseService<User> {

}
