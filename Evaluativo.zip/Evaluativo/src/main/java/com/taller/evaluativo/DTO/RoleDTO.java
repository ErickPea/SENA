package com.taller.evaluativo.DTO;

public interface RoleDTO extends IGenericDto {

}
