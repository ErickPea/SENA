package com.taller.evaluativo.DTO;

public interface UserDTO extends IGenericDto {

}
