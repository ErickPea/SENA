package com.taller.evaluativo.IRepository;

import com.taller.evaluativo.Entity.Role;

public interface IRoleRepository extends IBaseRepository<Role, Long> {

}
