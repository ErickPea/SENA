package com.taller.evaluativo.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.taller.evaluativo.Entity.ABaseEntity;
import com.taller.evaluativo.Entity.ModuloEntity;
import com.taller.evaluativo.Entity.Role;
import com.taller.evaluativo.IRepository.IBaseRepository;
import com.taller.evaluativo.IRepository.IModuloRepository;
import com.taller.evaluativo.IRepository.IRoleRepository;
import com.taller.evaluativo.IService.IModuloService;
@Service
public class ModuloService extends ABaseService<ModuloEntity> implements IModuloService {

	@Autowired
	private IModuloRepository repository;

	
	

	@Override
	protected IBaseRepository<ModuloEntity, Long> getRepository() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
