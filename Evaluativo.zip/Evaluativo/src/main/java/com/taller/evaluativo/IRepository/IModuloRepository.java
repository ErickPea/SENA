package com.taller.evaluativo.IRepository;
import com.taller.evaluativo.Entity.ModuloEntity;

public interface IModuloRepository extends IBaseRepository <ModuloEntity, Long> {

}
