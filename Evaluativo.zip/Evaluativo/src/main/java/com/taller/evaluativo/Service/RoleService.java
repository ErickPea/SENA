package com.taller.evaluativo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.taller.evaluativo.Entity.Role;
import com.taller.evaluativo.IRepository.IBaseRepository;
import com.taller.evaluativo.IRepository.IRoleRepository;
import com.taller.evaluativo.IService.IRoleService;

@Service
public class RoleService extends ABaseService<Role> implements IRoleService {

	@Autowired
	private IRoleRepository repository;

	@Override
	protected IBaseRepository<Role, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}

}
