package com.taller.evaluativo.DTO;

public interface IModuloDTO extends IGenericDto {

}
