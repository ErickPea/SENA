package com.taller.evaluativo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvaluativoApplication {

	public static void main(String[] args) {
		SpringApplication.run( EvaluativoApplication .class, args);
	}

}
