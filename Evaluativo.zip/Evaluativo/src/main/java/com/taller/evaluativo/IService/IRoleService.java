package com.taller.evaluativo.IService;

import com.taller.evaluativo.Entity.Role;

public interface IRoleService extends IBaseService<Role> {

}
