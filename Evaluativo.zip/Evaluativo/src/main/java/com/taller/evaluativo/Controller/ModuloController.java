package com.taller.evaluativo.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.taller.evaluativo.Entity.ModuloEntity;

import com.taller.evaluativo.IService.IModuloService;

@CrossOrigin (origins = "*")
@RestController
@RequestMapping("/v1/api/modulo")
public class ModuloController extends ABaseController <ModuloEntity, IModuloService  > {
	
	protected  ModuloController(IModuloService service) {
		super(service, "modulo");
		
	}

}
