package com.taller.evaluativo.IRepository;

import com.taller.evaluativo.Entity.User;

public interface IUserRepository extends IBaseRepository<User, Long> {

}
